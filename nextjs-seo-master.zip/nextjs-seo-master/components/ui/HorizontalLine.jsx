export default function HorizontalLine() {
    return (
        <div className='flex items-center pl-6'>
            <div className="w-32 h-0.5 flex items-center bg-white"></div>
        </div>
    )
}