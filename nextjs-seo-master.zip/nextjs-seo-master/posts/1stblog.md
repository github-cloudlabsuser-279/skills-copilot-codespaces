---
title: First Blog
date: 2023-09-01
image: /1stblog/smiley.png
alt: rescription of picture
---

This is my first blog post