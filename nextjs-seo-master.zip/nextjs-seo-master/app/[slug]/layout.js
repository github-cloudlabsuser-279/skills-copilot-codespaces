export default function RootLayout({ children }) {
  return (
    <div>
       
        {children}
        <div className="text-center text-white">
        {/* <h2>Other Content You Might Like</h2> */}
        </div>
    </div>
  )
}
